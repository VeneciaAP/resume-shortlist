if (!(Get-Command python -ErrorAction SilentlyContinue)) {
    Write-Host "Python is not installed. Please install Python 3.8 or newer and re-run this script." -ForegroundColor Red
    exit 1
}

if (!(Test-Path ".venv")) {
    python -m venv .venv
}

$venvActivate = ".venv\Scripts\Activate.ps1"
. $venvActivate

pip install --upgrade pip
pip install -r requirements.txt

python "AI screening.py"
